package com.example.supplementtracker.presentation.home

import android.app.Activity
import android.content.Intent
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.supplementtracker.R
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.supplementtracker.domain.model.UserSupplement
import com.example.supplementtracker.domain.model.CycleStatus
import com.example.supplementtracker.domain.usecase.CalculateCycleUseCase
import java.time.LocalDate

import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.sp
import com.example.supplementtracker.presentation.navigation.AppTheme
import com.example.supplementtracker.presentation.navigation.ActiveClientManager
import com.example.supplementtracker.domain.model.ClientProfile
import com.example.supplementtracker.domain.export.SupplementExportCycleDTO
import com.example.supplementtracker.domain.export.SupplementExportFileDTO
import com.example.supplementtracker.domain.export.SupplementExportJson
import com.example.supplementtracker.domain.export.SupplementExportSchema
import com.example.supplementtracker.domain.export.SupplementExportSupplementDTO
import com.example.supplementtracker.presentation.share.StackShareItem
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.platform.LocalSavedStateRegistryOwner
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.compose.runtime.rememberCompositionContext
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.ui.text.style.TextOverflow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    homeViewModel: HomeViewModel,
    activeClientManager: ActiveClientManager,
    appTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    val context = LocalContext.current
    val uiState by homeViewModel.uiState.collectAsStateWithLifecycle()
    val clientsRaw by activeClientManager.clients.collectAsStateWithLifecycle()
    val clients = remember(clientsRaw) { clientsRaw.distinctBy { it.id } }
    val currentClientId by activeClientManager.currentClientId.collectAsStateWithLifecycle()
    val dataTransferMessage by homeViewModel.dataTransferMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val lifecycleOwner = LocalLifecycleOwner.current
    val savedStateRegistryOwner = LocalSavedStateRegistryOwner.current
    val viewModelStoreOwner = LocalViewModelStoreOwner.current
    val compositionContext = rememberCompositionContext()
    val coroutineScope = rememberCoroutineScope()
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val shareChooserTitle = stringResource(R.string.share_stack)
    var isAddClientDialogVisible by remember { mutableStateOf(false) }
    var isEditClientDialogVisible by remember { mutableStateOf(false) }
    var editingClient by remember { mutableStateOf<ClientProfile?>(null) }
    var clientNameInput by remember { mutableStateOf("") }
    var isFactoryResetDialogVisible by remember { mutableStateOf(false) }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }

    val createJsonDocument = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val json = pendingExportJson ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult
        context.contentResolver.openOutputStream(uri)?.use { output ->
            output.write(json.toByteArray(Charsets.UTF_8))
        }
        pendingExportJson = null
    }

    val openJsonDocument = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val json = context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8)
        } ?: return@rememberLauncherForActivityResult
        homeViewModel.importSupplementsFromJson(json)
    }

    LaunchedEffect(dataTransferMessage) {
        val message = dataTransferMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        homeViewModel.clearDataTransferMessage()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                    title = { Text(stringResource(R.string.settings_title)) }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    LogoCard()
                }

                item {
                    ClientManagementCard(
                        clients = clients,
                        currentClientId = currentClientId,
                        onSelect = { activeClientManager.setCurrentClientId(it) },
                        onAdd = { isAddClientDialogVisible = true },
                        onEdit = {
                            editingClient = it
                            clientNameInput = it.name
                            isEditClientDialogVisible = true
                        },
                        onDelete = { client ->
                            val deletingActive = client.id == currentClientId
                            homeViewModel.deleteClient(client)
                            if (deletingActive) {
                                activeClientManager.setCurrentClientId(null)
                            }
                        }
                    )
                }

                item {
                    AppearanceCard(
                        appTheme = appTheme,
                        onThemeChange = onThemeChange
                    )
                }

                item {
                    Text(
                        text = stringResource(R.string.app_information_title),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.fillMaxWidth(),
                        fontWeight = FontWeight.Bold
                    )
                }

                if (uiState is HomeUiState.Success) {
                    val successState = uiState as HomeUiState.Success
                    val allSupplements = (successState.activeSupplements.values.flatten().map { it.supplement } +
                        successState.restingSupplements.map { it.supplement })
                        .distinctBy { it.id }
                        .sortedBy { it.name }

                    item {
                        Text(
                            text = stringResource(R.string.my_list_title),
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.fillMaxWidth(),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(items = allSupplements) { supplement ->
                        InfoCard(
                            title = supplement.name,
                            content = getCycleSummary(supplement)
                        )
                    }
                }

                item {
                    InfoCard(
                        title = stringResource(R.string.settings_guide_title),
                        content = stringResource(R.string.settings_guide_content)
                    )
                }

                item {
                    InfoCard(
                        title = stringResource(R.string.settings_intro_title),
                        content = stringResource(R.string.settings_intro_content)
                    )
                }

                item {
                    InfoCard(
                        title = stringResource(R.string.settings_copyright_title),
                        content = """
                            ${stringResource(R.string.settings_app_version)}
                            ${stringResource(R.string.settings_author)}
                            ${stringResource(R.string.settings_copyright)}
                        """.trimIndent()
                    )
                }

                item {
                    if (currentClientId != null) {
                        val allSupplements = when (uiState) {
                            is HomeUiState.Success -> {
                                val successState = uiState as HomeUiState.Success
                                (successState.activeSupplements.values.flatten().map { it.supplement } +
                                    successState.restingSupplements.map { it.supplement })
                                    .distinctBy { it.id }
                            }
                            else -> emptyList()
                        }

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    val dto = SupplementExportFileDTO(
                                        schemaVersion = SupplementExportSchema.VERSION,
                                        exportedAtEpochMs = System.currentTimeMillis(),
                                        supplements = allSupplements.map { supplement ->
                                            SupplementExportSupplementDTO(
                                                name = supplement.name,
                                                dailyDose = supplement.dailyDose,
                                                intakeTime = supplement.intakeTime,
                                                startDate = supplement.startDate.toString(),
                                                category = null,
                                                cycle = SupplementExportCycleDTO(
                                                    isContinuous = supplement.cycleConfig.isContinuous,
                                                    daysOn = supplement.cycleConfig.daysOn,
                                                    daysOff = supplement.cycleConfig.daysOff,
                                                    durationMonths = supplement.cycleConfig.durationMonths
                                                )
                                            )
                                        }
                                    )
                                    pendingExportJson = SupplementExportJson.encode(dto)
                                    createJsonDocument.launch("OAKHealthy_Stack.json")
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.export_data))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { openJsonDocument.launch(arrayOf("application/json")) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.import_data))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    coroutineScope.launch(Dispatchers.Main) {
                                        var current: Any? = context
                                        var activity: Activity? = null
                                        while (current is ContextWrapper) {
                                            if (current is Activity) {
                                                activity = current
                                                break
                                            }
                                            current = current.baseContext
                                        }
                                        if (activity == null && current is Activity) {
                                            activity = current
                                        }
                                        if (activity == null) {
                                            Toast.makeText(context, "Context is not an Activity", Toast.LENGTH_SHORT).show()
                                            return@launch
                                        }

                                        val rootView = activity.window.decorView.findViewById<ViewGroup>(android.R.id.content)
                                        var captureView: ComposeView? = null
                                        try {
                                            val shareItems = allSupplements
                                                .sortedBy { it.intakeTime }
                                                .map { StackShareItem(name = it.name, dose = it.dailyDose, time = it.intakeTime) }

                                            val displayMetrics = context.resources.displayMetrics
                                            val targetWidth = displayMetrics.widthPixels
                                            val fallbackHeight = (displayMetrics.density * 2000f).toInt()

                                            val composeView = ComposeView(context).apply {
                                                setViewTreeLifecycleOwner(lifecycleOwner)
                                                setViewTreeSavedStateRegistryOwner(savedStateRegistryOwner)
                                                viewModelStoreOwner?.let { setViewTreeViewModelStoreOwner(it) }
                                                setParentCompositionContext(compositionContext)
                                                alpha = 0f
                                                setContent {
                                                    MaterialTheme {
                                                        Surface(color = MaterialTheme.colorScheme.background) {
                                                            StackShareSnapshotView(items = shareItems, isDark = isDark)
                                                        }
                                                    }
                                                }
                                            }
                                            captureView = composeView

                                            rootView.addView(
                                                composeView,
                                                ViewGroup.LayoutParams(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT)
                                            )

                                            composeView.post {
                                                coroutineScope.launch(Dispatchers.Main) {
                                                    try {
                                                        val widthSpec = View.MeasureSpec.makeMeasureSpec(targetWidth, View.MeasureSpec.EXACTLY)
                                                        val heightSpec = View.MeasureSpec.makeMeasureSpec(10_000, View.MeasureSpec.AT_MOST)
                                                        composeView.measure(widthSpec, heightSpec)

                                                        val width = if (composeView.measuredWidth > 0) composeView.measuredWidth else targetWidth
                                                        val height = if (composeView.measuredHeight > 0) composeView.measuredHeight else fallbackHeight
                                                        composeView.layout(0, 0, width, height)

                                                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                                        val canvas = Canvas(bitmap)
                                                        canvas.drawColor(if (isDark) AndroidColor.parseColor("#121212") else AndroidColor.parseColor("#FFFFFF"))
                                                        composeView.draw(canvas)
                                                        rootView.removeView(composeView)
                                                        composeView.disposeComposition()

                                                        val imageFile = withContext(Dispatchers.IO) {
                                                            val cachePath = File(context.cacheDir, "shared_images")
                                                            cachePath.mkdirs()
                                                            val target = File(cachePath, "oak_stack_${System.currentTimeMillis()}.png")
                                                            FileOutputStream(target).use { stream ->
                                                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                                                                stream.flush()
                                                            }
                                                            target
                                                        }

                                                        val uri = FileProvider.getUriForFile(
                                                            context,
                                                            "${context.packageName}.fileprovider",
                                                            imageFile
                                                        )

                                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                                            type = "image/png"
                                                            putExtra(Intent.EXTRA_STREAM, uri)
                                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                        }
                                                        context.startActivity(Intent.createChooser(intent, "Share Stack via"))
                                                    } catch (e: Exception) {
                                                        rootView.removeView(composeView)
                                                        composeView.disposeComposition()
                                                        Log.e("ShareStack", "Failed to draw bitmap", e)
                                                        Toast.makeText(context, "Lỗi vẽ ảnh: ${e.message ?: "Unknown"}", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            }
                                        } catch (e: Exception) {
                                            captureView?.let { view ->
                                                rootView.removeView(view)
                                                view.disposeComposition()
                                            }
                                            Log.e("ShareStack", "Error sharing stack", e)
                                            e.printStackTrace()
                                            Toast.makeText(context, "Lỗi chia sẻ: ${e.message ?: "Unknown"}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.share_stack))
                            }
                        }
                    }
                }

                item {
                    TextButton(onClick = { isFactoryResetDialogVisible = true }) {
                        Text(
                            text = stringResource(R.string.factory_reset),
                            color = Color(0xFFD32F2F),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }

    if (isFactoryResetDialogVisible) {
        AlertDialog(
            onDismissRequest = { isFactoryResetDialogVisible = false },
            title = { Text(stringResource(R.string.factory_reset)) },
            text = { Text(stringResource(R.string.wipe_data_warning)) },
            confirmButton = {
                TextButton(onClick = {
                    clients.forEach { homeViewModel.deleteClient(it) }
                    activeClientManager.setCurrentClientId(null)
                    isFactoryResetDialogVisible = false
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { isFactoryResetDialogVisible = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (isAddClientDialogVisible) {
        AlertDialog(
            onDismissRequest = { isAddClientDialogVisible = false },
            title = { Text(stringResource(R.string.add_a_client)) },
            text = {
                OutlinedTextField(
                    value = clientNameInput,
                    onValueChange = { clientNameInput = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmed = clientNameInput.trim()
                    if (trimmed.isEmpty()) return@TextButton
                    val created = ClientProfile(id = UUID.randomUUID(), name = trimmed, avatarColorArgb = 0)
                    homeViewModel.createClient(created)
                    activeClientManager.setCurrentClientId(created.id)
                    clientNameInput = ""
                    isAddClientDialogVisible = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = {
                    clientNameInput = ""
                    isAddClientDialogVisible = false
                }) { Text("Cancel") }
            }
        )
    }

    if (isEditClientDialogVisible) {
        val target = editingClient
        if (target != null) {
            AlertDialog(
                onDismissRequest = { isEditClientDialogVisible = false },
                title = { Text(stringResource(R.string.edit)) },
                text = {
                    OutlinedTextField(
                        value = clientNameInput,
                        onValueChange = { clientNameInput = it },
                        label = { Text("Name") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val trimmed = clientNameInput.trim()
                        if (trimmed.isEmpty()) return@TextButton
                        homeViewModel.updateClient(target.copy(name = trimmed))
                        clientNameInput = ""
                        isEditClientDialogVisible = false
                    }) { Text("Save") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        clientNameInput = ""
                        isEditClientDialogVisible = false
                    }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun StackShareSnapshotView(
    items: List<StackShareItem>,
    isDark: Boolean
) {
    val shape = RoundedCornerShape(32.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(32.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = shape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "OAK Healthy",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "My Stack",
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = item.time,
                            fontSize = 12.sp,
                            modifier = Modifier.width(72.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.dose,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "oakhealthy.app",
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun AppearanceCard(
    appTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(stringResource(R.string.appearance_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            AppThemeSegmentedControl(
                appTheme = appTheme,
                onThemeChange = onThemeChange
            )
        }
    }
}

@Composable
private fun AppThemeSegmentedControl(
    appTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    val outerColor = MaterialTheme.colorScheme.surfaceVariant
    val selectedColor = MaterialTheme.colorScheme.surface

    val items = listOf(
        Triple(stringResource(R.string.appearance_light), AppTheme.LIGHT, appTheme == AppTheme.LIGHT),
        Triple(stringResource(R.string.appearance_dark), AppTheme.DARK, appTheme == AppTheme.DARK),
        Triple(stringResource(R.string.appearance_system), AppTheme.SYSTEM, appTheme == AppTheme.SYSTEM)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(outerColor, RoundedCornerShape(28.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items.forEach { (label, theme, selected) ->
            val pillShape = RoundedCornerShape(22.dp)
            Surface(
                modifier = Modifier.weight(1f),
                shape = pillShape,
                color = if (selected) selectedColor else outerColor,
                tonalElevation = 0.dp,
                shadowElevation = 0.dp
            ) {
                TextButton(
                    onClick = { onThemeChange(theme) },
                    colors = ButtonDefaults.textButtonColors(containerColor = Color.Transparent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = label,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun getCycleSummary(supplement: UserSupplement): String {
    val config = supplement.cycleConfig
    val calculateCycleUseCase = CalculateCycleUseCase()
    val status = calculateCycleUseCase(supplement.startDate, config, LocalDate.now())
    val statusText = if (status == CycleStatus.ON) {
        R.string.cycle_status_on
    } else {
        R.string.cycle_status_off
    }

    return if (config.isContinuous) {
        stringResource(R.string.cycle_continuous)
    } else {
        stringResource(R.string.cycle_summary_format, stringResource(statusText), config.daysOn, config.daysOff)
    }
}

@Composable
private fun InfoCard(title: String, content: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                style = MaterialTheme.typography.bodyMedium,
                lineHeight = MaterialTheme.typography.bodyMedium.lineHeight * 1.2
            )
        }
    }
}

@Composable
private fun ClientManagementCard(
    clients: List<ClientProfile>,
    currentClientId: UUID?,
    onSelect: (UUID?) -> Unit,
    onAdd: () -> Unit,
    onEdit: (ClientProfile) -> Unit,
    onDelete: (ClientProfile) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(text = stringResource(R.string.client_management), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            if (clients.isEmpty()) {
                Text(text = stringResource(R.string.add_client_to_start), style = MaterialTheme.typography.bodyMedium)
            } else {
                clients.forEach { client ->
                    key(client.id) {
                        var isMenuExpanded by remember { mutableStateOf(false) }
                        val isActive = client.id == currentClientId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = client.name, modifier = Modifier.weight(1f))
                            if (isActive) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                            }

                            IconButton(onClick = { isMenuExpanded = true }) {
                                Icon(imageVector = Icons.Default.MoreVert, contentDescription = null)
                            }

                            DropdownMenu(
                                expanded = isMenuExpanded,
                                onDismissRequest = { isMenuExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.select)) },
                                    onClick = {
                                        onSelect(client.id)
                                        isMenuExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.edit)) },
                                    onClick = {
                                        onEdit(client)
                                        isMenuExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.delete)) },
                                    onClick = {
                                        onDelete(client)
                                        isMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onAdd) {
                Text(stringResource(R.string.add_a_client))
            }
        }
    }
}

@Composable
private fun LogoCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                imageVector = ImageVector.vectorResource(R.drawable.ic_oak_logo),
                contentDescription = null,
                modifier = Modifier.size(96.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.settings_dedication),
                style = MaterialTheme.typography.bodyMedium,
                fontStyle = FontStyle.Italic
            )
        }
    }
}
